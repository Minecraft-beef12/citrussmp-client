package net.citrussmp.client.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.entity.player.PlayerSkin;
import net.minecraft.core.ClientAsset;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Gives the local player the CitrusSMP cape everywhere (singleplayer and every server).
 */
@Mixin(AbstractClientPlayer.class)
public abstract class CapeMixin {

    private static final Identifier CITRUS_CAPE =
            Identifier.fromNamespaceAndPath("citrussmp", "entity/cape");

    @Inject(method = "getSkin", at = @At("RETURN"), cancellable = true)
    private void citrussmp$cape(CallbackInfoReturnable<PlayerSkin> cir) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || (Object) this != mc.player) {
            return;
        }
        PlayerSkin skin = cir.getReturnValue();
        ClientAsset.ResourceTexture cape = new ClientAsset.ResourceTexture(CITRUS_CAPE);
        cir.setReturnValue(new PlayerSkin(skin.body(), cape, cape, skin.model(), skin.secure()));
    }
}
