package net.citrussmp.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.multiplayer.ServerData;

public class CitrusClient implements ClientModInitializer {
    /** Part of the server address that identifies CitrusSMP. */
    private static final String SERVER_HOST_PART = "citrussmp";

    @Override
    public void onInitializeClient() {
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            ServerData server = client.getCurrentServer();
            if (server != null && server.ip != null
                    && server.ip.toLowerCase().contains(SERVER_HOST_PART)) {
                handler.sendCommand("citrusclient");
            }
        });
    }
}
