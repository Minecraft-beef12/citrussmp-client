# CitrusSMP Client

Official CitrusSMP client for Minecraft Java 26.2 (Windows and Mac).

## Install (about 3 minutes)
1. Install the free **Modrinth App**: https://modrinth.com/app
2. Open it, click **+ Create instance**, name it `CitrusSMP`, pick **Fabric** and Minecraft **26.2**.
3. Open the instance, click **Add content** and add **Fabric API** and **Xaero's Minimap** (this is the minimap; set its corner in its settings).
4. Download **CitrusSMP-Client.jar** and **CitrusSMP-Resources.zip** from the Releases page here.
5. In the instance, open **Content / Add from file** and add both files. (Or drop the jar in the `mods` folder and the zip in `resourcepacks`.)
6. Turn on the **CitrusSMP-Resources** pack in Options > Resource Packs.
7. Press Play.

## What you get
- Title screen shows CitrusSMP
- CitrusSMP cape (on every server and in singleplayer)
- Black menu borders
- On CitrusSMP: a star next to your name in chat and over your head
